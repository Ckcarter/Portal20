package net.mistersecret312.aperture_innovations.sounds;

public class SoundWrapper
{
	public SoundWrapper(){}

	public boolean isPlaying()
	{
		return false;
	}

	public boolean hasSound()
	{
		return false;
	}

	public void playSound(){}

	public void stopSound(){}
}