package net.mistersecret312.aperture_innovations.client.model;

import com.mojang.blaze3d.vertex.PoseStack;
import com.mojang.blaze3d.vertex.VertexConsumer;
import net.minecraft.client.model.EntityModel;
import net.minecraft.client.model.geom.*;
import net.minecraft.client.model.geom.builders.*;
import net.mistersecret312.aperture_innovations.entities.SentryTurretEntity;

/** Exact geometry conversion of iChun PortalGun 1.7.10 ModelTurret. */
public class SentryTurretModel extends EntityModel<SentryTurretEntity> {
 private final ModelPart root;
 private final ModelPart frontR;
 private final ModelPart frontLegR;
 private final ModelPart frontLegL;
 private final ModelPart frontL;
 private final ModelPart sideL;
 private final ModelPart sideR;
 private final ModelPart mainBodySR;
 private final ModelPart eye;
 private final ModelPart back;
 private final ModelPart backLeg;
 private final ModelPart backProng3;
 private final ModelPart backProng1;
 private final ModelPart backProng2;
 private final ModelPart mainBodyCR;
 private final ModelPart mainBodySL;
 private final ModelPart mainBodyCL;
 private final ModelPart mainBodyFT;
 private final ModelPart frontLProng1;
 private final ModelPart frontLProng2;
 private final ModelPart frontLProng3;
 private final ModelPart frontLProng4;
 private final ModelPart frontRProng1;
 private final ModelPart frontRProng2;
 private final ModelPart frontRProng3;
 private final ModelPart frontRProng4;
 private final ModelPart sideSupportR;
 private final ModelPart sideSupportL;
 private final ModelPart sideGunR;
 private final ModelPart sideGunL;
 private final ModelPart barrelTopR;
 private final ModelPart barrelBottomR;
 private final ModelPart barrelTopL;
 private final ModelPart barrelBottomL;
 public SentryTurretModel(ModelPart root){ this.root=root;
  this.frontR=root.getChild("frontR");
  this.frontLegR=root.getChild("frontLegR");
  this.frontLegL=root.getChild("frontLegL");
  this.frontL=root.getChild("frontL");
  this.sideL=root.getChild("sideL");
  this.sideR=root.getChild("sideR");
  this.mainBodySR=root.getChild("mainBodySR");
  this.eye=root.getChild("eye");
  this.back=root.getChild("back");
  this.backLeg=root.getChild("backLeg");
  this.backProng3=root.getChild("backProng3");
  this.backProng1=root.getChild("backProng1");
  this.backProng2=root.getChild("backProng2");
  this.mainBodyCR=root.getChild("mainBodyCR");
  this.mainBodySL=root.getChild("mainBodySL");
  this.mainBodyCL=root.getChild("mainBodyCL");
  this.mainBodyFT=root.getChild("mainBodyFT");
  this.frontLProng1=root.getChild("frontLProng1");
  this.frontLProng2=root.getChild("frontLProng2");
  this.frontLProng3=root.getChild("frontLProng3");
  this.frontLProng4=root.getChild("frontLProng4");
  this.frontRProng1=root.getChild("frontRProng1");
  this.frontRProng2=root.getChild("frontRProng2");
  this.frontRProng3=root.getChild("frontRProng3");
  this.frontRProng4=root.getChild("frontRProng4");
  this.sideSupportR=root.getChild("sideSupportR");
  this.sideSupportL=root.getChild("sideSupportL");
  this.sideGunR=root.getChild("sideGunR");
  this.sideGunL=root.getChild("sideGunL");
  this.barrelTopR=root.getChild("barrelTopR");
  this.barrelBottomR=root.getChild("barrelBottomR");
  this.barrelTopL=root.getChild("barrelTopL");
  this.barrelBottomL=root.getChild("barrelBottomL");
 }
 public static LayerDefinition createBodyLayer(){ MeshDefinition mesh=new MeshDefinition(); PartDefinition root=mesh.getRoot();
  root.addOrReplaceChild("frontR",CubeListBuilder.create().texOffs(0,17).addBox(-2.000000F,0.000000F,0.000000F,2.000000F,4.000000F,1.000000F,new CubeDeformation(0.000000F)),PartPose.offsetAndRotation(-1.500000F,16.200000F,-4.000000F,-1.175270F,0.452023F,0.000000F));
  root.addOrReplaceChild("frontLegR",CubeListBuilder.create().texOffs(6,17).addBox(-1.000000F,0.000000F,0.000000F,1.000000F,6.000000F,1.000000F,new CubeDeformation(0.000000F)),PartPose.offsetAndRotation(-3.500000F,18.000000F,-7.000000F,-0.180816F,0.452023F,0.000000F));
  root.addOrReplaceChild("frontLegL",CubeListBuilder.create().texOffs(6,17).addBox(0.000000F,0.000000F,0.000000F,1.000000F,6.000000F,1.000000F,new CubeDeformation(0.000000F)),PartPose.offsetAndRotation(3.500000F,18.000000F,-7.000000F,-0.180811F,-0.452028F,0.000000F));
  root.addOrReplaceChild("frontL",CubeListBuilder.create().texOffs(0,17).addBox(0.000000F,0.000000F,0.000000F,2.000000F,4.000000F,1.000000F,new CubeDeformation(0.000000F)),PartPose.offsetAndRotation(1.500000F,16.200000F,-4.000000F,-1.175272F,-0.452028F,0.000000F));
  root.addOrReplaceChild("sideL",CubeListBuilder.create().texOffs(14,0).mirror().addBox(2.800000F,-4.500000F,-2.000000F,1.000000F,9.000000F,4.000000F,new CubeDeformation(0.000000F)),PartPose.offsetAndRotation(1.500000F,10.500000F,-2.000000F,0.000000F,0.000000F,0.000000F));
  root.addOrReplaceChild("sideR",CubeListBuilder.create().texOffs(14,0).addBox(-3.800000F,-4.500000F,-2.000000F,1.000000F,9.000000F,4.000000F,new CubeDeformation(0.000000F)),PartPose.offsetAndRotation(-1.500000F,10.500000F,-2.000000F,0.000000F,0.000000F,0.000000F));
  root.addOrReplaceChild("mainBodySR",CubeListBuilder.create().texOffs(10,13).mirror().addBox(-1.500000F,0.000000F,-3.000000F,1.000000F,11.000000F,6.000000F,new CubeDeformation(0.000000F)),PartPose.offsetAndRotation(0.000000F,5.000000F,-2.000000F,0.000000F,0.000000F,0.000000F));
  root.addOrReplaceChild("eye",CubeListBuilder.create().texOffs(9,0).addBox(-0.500000F,-0.500000F,-0.200000F,1.000000F,1.000000F,1.000000F,new CubeDeformation(0.000000F)),PartPose.offsetAndRotation(0.000000F,10.500000F,-5.000000F,0.000000F,0.000000F,0.785398F));
  root.addOrReplaceChild("back",CubeListBuilder.create().texOffs(0,17).addBox(-1.000000F,0.000000F,-1.000000F,2.000000F,5.000000F,1.000000F,new CubeDeformation(0.000000F)),PartPose.offsetAndRotation(0.000000F,12.000000F,2.000000F,0.904055F,0.000000F,0.000000F));
  root.addOrReplaceChild("backLeg",CubeListBuilder.create().texOffs(6,17).addBox(-0.500000F,0.000000F,0.000000F,1.000000F,9.000000F,1.000000F,new CubeDeformation(0.000000F)),PartPose.offsetAndRotation(0.000000F,15.000000F,4.500000F,0.090406F,0.000000F,0.000000F));
  root.addOrReplaceChild("backProng3",CubeListBuilder.create().texOffs(0,0).addBox(-0.500000F,0.000000F,0.000000F,1.000000F,2.000000F,1.000000F,new CubeDeformation(0.000000F)),PartPose.offsetAndRotation(0.000000F,14.000000F,3.000000F,-0.602139F,0.000000F,0.000000F));
  root.addOrReplaceChild("backProng1",CubeListBuilder.create().texOffs(0,0).addBox(-0.500000F,0.000000F,0.000000F,1.000000F,1.000000F,1.000000F,new CubeDeformation(0.000000F)),PartPose.offsetAndRotation(0.000000F,16.000000F,0.000000F,0.858853F,0.000000F,0.000000F));
  root.addOrReplaceChild("backProng2",CubeListBuilder.create().texOffs(0,0).addBox(-0.500000F,-2.000000F,-1.000000F,1.000000F,2.000000F,1.000000F,new CubeDeformation(0.000000F)),PartPose.offsetAndRotation(0.000000F,16.660000F,0.750000F,-1.352630F,0.000000F,0.000000F));
  root.addOrReplaceChild("mainBodyCR",CubeListBuilder.create().texOffs(0,0).mirror().addBox(-1.500000F,0.000000F,-3.000000F,1.000000F,11.000000F,6.000000F,new CubeDeformation(0.000000F)),PartPose.offsetAndRotation(0.470000F,5.000000F,-2.000000F,0.000000F,0.000000F,0.000000F));
  root.addOrReplaceChild("mainBodySL",CubeListBuilder.create().texOffs(10,13).addBox(0.500000F,0.000000F,-3.000000F,1.000000F,11.000000F,6.000000F,new CubeDeformation(0.000000F)),PartPose.offsetAndRotation(0.000000F,5.000000F,-2.000000F,0.000000F,0.000000F,0.000000F));
  root.addOrReplaceChild("mainBodyCL",CubeListBuilder.create().texOffs(0,0).addBox(0.000000F,0.000000F,-3.000000F,1.000000F,11.000000F,6.000000F,new CubeDeformation(0.000000F)),PartPose.offsetAndRotation(0.030000F,5.000000F,-2.000000F,0.000000F,0.000000F,0.000000F));
  root.addOrReplaceChild("mainBodyFT",CubeListBuilder.create().texOffs(24,0).addBox(-0.500000F,0.000000F,-3.000000F,1.000000F,10.000000F,5.000000F,new CubeDeformation(0.000000F)),PartPose.offsetAndRotation(0.000000F,5.500000F,-1.500000F,0.000000F,0.000000F,0.000000F));
  root.addOrReplaceChild("frontLProng1",CubeListBuilder.create().texOffs(0,0).addBox(-0.500000F,0.000000F,-1.000000F,1.000000F,2.000000F,1.000000F,new CubeDeformation(0.000000F)),PartPose.offsetAndRotation(0.660000F,16.000000F,0.840000F,-0.361622F,-0.361622F,0.000000F));
  root.addOrReplaceChild("frontLProng2",CubeListBuilder.create().texOffs(0,0).addBox(-0.600000F,0.000000F,-1.000000F,1.000000F,2.000000F,1.000000F,new CubeDeformation(0.000000F)),PartPose.offsetAndRotation(1.000000F,17.870000F,0.210000F,-1.130062F,-0.361613F,0.000000F));
  root.addOrReplaceChild("frontLProng3",CubeListBuilder.create().texOffs(0,0).addBox(-1.000000F,0.000000F,-1.000000F,1.000000F,2.000000F,1.000000F,new CubeDeformation(0.000000F)),PartPose.offsetAndRotation(2.000000F,18.730000F,-1.320000F,-1.570796F,-0.406816F,0.000000F));
  root.addOrReplaceChild("frontLProng4",CubeListBuilder.create().texOffs(0,0).addBox(-0.180000F,0.100000F,-1.000000F,1.000000F,2.000000F,1.000000F,new CubeDeformation(0.000000F)),PartPose.offsetAndRotation(2.000000F,18.790000F,-3.400000F,-2.034125F,-0.406816F,0.000000F));
  root.addOrReplaceChild("frontRProng1",CubeListBuilder.create().texOffs(0,0).addBox(-0.500000F,0.000000F,-1.000000F,1.000000F,2.000000F,1.000000F,new CubeDeformation(0.000000F)),PartPose.offsetAndRotation(-0.660000F,16.000000F,0.840000F,-0.361615F,0.361615F,0.000000F));
  root.addOrReplaceChild("frontRProng2",CubeListBuilder.create().texOffs(0,0).addBox(-0.400000F,0.000000F,-1.000000F,1.000000F,2.000000F,1.000000F,new CubeDeformation(0.000000F)),PartPose.offsetAndRotation(-1.000000F,17.870000F,0.210000F,-1.130062F,0.361615F,0.000000F));
  root.addOrReplaceChild("frontRProng3",CubeListBuilder.create().texOffs(0,0).addBox(0.000000F,0.000000F,-1.000000F,1.000000F,2.000000F,1.000000F,new CubeDeformation(0.000000F)),PartPose.offsetAndRotation(-2.000000F,18.730000F,-1.320000F,-1.570796F,0.406819F,0.000000F));
  root.addOrReplaceChild("frontRProng4",CubeListBuilder.create().texOffs(0,0).addBox(-0.820000F,0.100000F,-1.000000F,1.000000F,2.000000F,1.000000F,new CubeDeformation(0.000000F)),PartPose.offsetAndRotation(-2.000000F,18.790000F,-3.400000F,-2.034125F,0.406819F,0.000000F));
  root.addOrReplaceChild("sideSupportR",CubeListBuilder.create().texOffs(21,0).addBox(-1.500000F,-0.500000F,-0.500000F,2.000000F,1.000000F,1.000000F,new CubeDeformation(0.000000F)),PartPose.offsetAndRotation(-1.500000F,10.500000F,-2.000000F,0.000000F,0.000000F,0.000000F));
  root.addOrReplaceChild("sideSupportL",CubeListBuilder.create().texOffs(21,0).addBox(-0.500000F,-0.500000F,-0.500000F,2.000000F,1.000000F,1.000000F,new CubeDeformation(0.000000F)),PartPose.offsetAndRotation(1.500000F,10.500000F,-2.000000F,0.000000F,0.000000F,0.000000F));
  root.addOrReplaceChild("sideGunR",CubeListBuilder.create().texOffs(24,15).addBox(-3.500000F,-2.000000F,-1.000000F,2.000000F,4.000000F,2.000000F,new CubeDeformation(0.000000F)),PartPose.offsetAndRotation(-1.500000F,10.500000F,-2.000000F,0.000000F,0.000000F,0.000000F));
  root.addOrReplaceChild("sideGunL",CubeListBuilder.create().texOffs(24,15).addBox(1.500000F,-2.000000F,-1.000000F,2.000000F,4.000000F,2.000000F,new CubeDeformation(0.000000F)),PartPose.offsetAndRotation(1.500000F,10.500000F,-2.000000F,0.000000F,0.000000F,0.000000F));
  root.addOrReplaceChild("barrelTopR",CubeListBuilder.create().texOffs(19,14).addBox(-2.650000F,-1.400000F,-1.800000F,1.000000F,1.000000F,1.000000F,new CubeDeformation(0.000000F)),PartPose.offsetAndRotation(-1.500000F,10.500000F,-2.000000F,0.000000F,0.000000F,0.000000F));
  root.addOrReplaceChild("barrelBottomR",CubeListBuilder.create().texOffs(19,14).addBox(-2.650000F,0.300000F,-1.800000F,1.000000F,1.000000F,1.000000F,new CubeDeformation(0.000000F)),PartPose.offsetAndRotation(-1.500000F,10.500000F,-2.000000F,0.000000F,0.000000F,0.000000F));
  root.addOrReplaceChild("barrelTopL",CubeListBuilder.create().texOffs(19,14).addBox(1.650000F,-1.400000F,-1.800000F,1.000000F,1.000000F,1.000000F,new CubeDeformation(0.000000F)),PartPose.offsetAndRotation(1.500000F,10.500000F,-2.000000F,0.000000F,0.000000F,0.000000F));
  root.addOrReplaceChild("barrelBottomL",CubeListBuilder.create().texOffs(19,14).addBox(1.650000F,0.300000F,-1.800000F,1.000000F,1.000000F,1.000000F,new CubeDeformation(0.000000F)),PartPose.offsetAndRotation(1.500000F,10.500000F,-2.000000F,0.000000F,0.000000F,0.000000F));
  return LayerDefinition.create(mesh,64,32); }
 @Override public void setupAnim(SentryTurretEntity e,float ls,float la,float age,float yaw,float pitch){
  // Exact PortalGun 1.7.10 ModelTurret deployment formula:
  // retraction 0 -> -1.3, retraction 10 -> +1.5.
  float retract=(e.getRetraction()*0.28F)-1.3F;

  sideR.x=-retract;
  sideGunR.x=-retract;
  barrelTopR.x=-retract;
  barrelBottomR.x=-retract;
  sideSupportR.x=-retract;

  sideL.x=retract;
  sideGunL.x=retract;
  barrelTopL.x=retract;
  barrelBottomL.x=retract;
  sideSupportL.x=retract;

  if(retract<0.5F){
   sideSupportR.x=-0.5F;
   sideSupportL.x=0.5F;
  }

  float aimYaw=e.getTurretAimYaw()-e.getYRot();
  float aimPitch=e.getTurretAimPitch();
  float yr=aimYaw*0.017453292F;
  float xr=aimPitch*0.017453292F;

  sideL.yRot=yr; sideL.xRot=xr;
  sideR.yRot=yr; sideR.xRot=xr;
  sideGunR.yRot=yr; sideGunR.xRot=xr;
  sideGunL.yRot=yr; sideGunL.xRot=xr;
  barrelTopR.yRot=yr; barrelTopR.xRot=xr;
  barrelTopL.yRot=yr; barrelTopL.xRot=xr;
  barrelBottomR.yRot=yr; barrelBottomR.xRot=xr;
  barrelBottomL.yRot=yr; barrelBottomL.xRot=xr;
  sideSupportL.yRot=yr; sideSupportL.xRot=xr;
  sideSupportR.yRot=yr; sideSupportR.xRot=xr;
 }
 @Override public void renderToBuffer(PoseStack p,VertexConsumer v,int light,int overlay,float r,float g,float b,float a){root.render(p,v,light,overlay,r,g,b,a);}
}